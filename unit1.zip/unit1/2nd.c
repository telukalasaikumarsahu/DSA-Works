#include <stdio.h>

int main()
{
    int a[100], n, i, j, key;
    int shifts = 0;

    printf("Enter number of students: ");
    scanf("%d", &n);

    printf("Enter student marks:\n");
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);

    printf("\nArray after each pass:\n");

    for (i = 1; i < n; i++)
    {
        key = a[i];
        j = i - 1;

        while (j >= 0 && a[j] > key)
        {
            a[j + 1] = a[j];
            shifts++;
            j--;
        }

        a[j + 1] = key;

        printf("Pass %d: ", i);
        for (j = 0; j < n; j++)
            printf("%d ", a[j]);
        printf("\n");
    }

    printf("\nFinal sorted list: ");
    for (i = 0; i < n; i++)
        printf("%d ", a[i]);

    printf("\nTotal number of element shifts = %d\n", shifts);

    return 0;
}